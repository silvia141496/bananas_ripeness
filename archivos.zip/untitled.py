import PySimpleGUI as sg
from datetime import date
import cv2

def main():
    up_left     = 'up-left.png'
    up_rigth    = 'up-rigth.png'
    down_left   = 'down-left.png'
    down_rigth  = 'down-rigth.png'