import PySimpleGUI as sg
from datetime import date
import cv2

def main():
    #Conectamos a la webcam
    camara = cv2.VideoCapture(0)

    #Elegimos un tema de PySimpleGUI
    sg.theme('DarkGreen5')
    #Definimos los elementos de la interfaz grafica
    layout = [[sg.Image(filename='', key='-image-')],
              [sg.Button('Tomar Fotografia'),sg.Button('Salir')]]
    #Creamos la interfaz grafica
    window = sg.Window('Camara FACIALIX',
                       layout,
                       no_titlebar=False,
                       location=(0, 0))

    image_elem = window['-image-']

    numero = 0
    #Iniciamos la lectura y actualizacion
    while camara.isOpened():
        #Obtenemos informacion de la interfaz grafica y video
        event, values = window.read(timeout=0)
        ret, frame = camara.read()

        #Si salimos
        if event in ('Exit', None):
            break

        #Si tomamos foto
        elif event == 'Tomar Fotografia':
            ruta = sg.popup_get_folder(title='Guardar Fotografia', message="Carpeta destino")
            cv2.imwrite(ruta + "/" + str(date.today()) + str(numero) + ".png", frame)

        if not ret:
            break

        #Mandamos el video a la GUI
        imgbytes = cv2.imencode('.png', frame)[1].tobytes()  # ditto
        image_elem.update(data=imgbytes)
        numero = numero + 1
main()


#layout2 = [[sg.Text('Enter a Number')],
#          [sg.Input()],
#                    [sg.OK()] ]

#layout = [[sg.Frame(layout=layout2, title='Options',title_color='red', relief=sg.RELIEF_SUNKEN, tooltip='Use these to set flags')],
#                        [sg.Text('Source for Folders', size=(15, 1)), sg.InputText(), sg.FolderBrowse()],
#                        [sg.Text('Source for Files ', size=(15, 1)), sg.InputText(), sg.FolderBrowse()],
#                        [sg.Submit(), sg.Cancel()]]

#window = sg.Window('Rename Files or Folders', layout)

#event, values = window.read()
#window.close()
#folder_path, file_path = values[0], values[1]       # get the data from the values dictionary
#print(folder_path, file_path)
