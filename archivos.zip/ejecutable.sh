#!/bin/bash
cd /home/pi/tflite1
source tflite1-env/bin/activate
cd interfaz_py
./interfaz_2.py
