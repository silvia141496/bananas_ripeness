import wx
from datetime import date
import cv2

class MyFrame(wx.Frame):    
	def __init__(self,parent,id,title,cams):
		self.cams= cams
		width = 960
		heigth = 700
		wx.Frame.__init__(self,parent,id,title,size=(width,heigth))
		self.parent = parent
		self.initialize()

	def initialize(self):
		self.Centre()
		self.SetBackgroundColour(wx.WHITE)
		width = 960
		heigth = 700
		up_left 	= 'up-left.png'
		up_rigth 	= 'up-rigth.png'
		down_left 	= 'down-left.png'
		down_rigth 	= 'down-rigth.png'
		img_up_left = wx.Bitmap(up_left)
		img_up_left = img_up_left.ConvertToImage()
		img_up_left = img_up_left.Scale(103, 212, wx.IMAGE_QUALITY_HIGH)
		img_up_left = img_up_left.ConvertToBitmap()
		img_up_rigth = wx.Bitmap(up_rigth)
		img_up_rigth = img_up_rigth.ConvertToImage()
		img_up_rigth = img_up_rigth.Scale(113, 211, wx.IMAGE_QUALITY_HIGH)
		img_up_rigth = img_up_rigth.ConvertToBitmap()
		img_down_left = wx.Bitmap(down_left)
		img_down_left = img_down_left.ConvertToImage()
		img_down_left = img_down_left.Scale(457, 107, wx.IMAGE_QUALITY_HIGH)
		img_down_left = img_down_left.ConvertToBitmap()
		img_down_rigth = wx.Bitmap(down_rigth)
		img_down_rigth = img_down_rigth.ConvertToImage()
		img_down_rigth = img_down_rigth.Scale(362, 135, wx.IMAGE_QUALITY_HIGH)
		img_down_rigth = img_down_rigth.ConvertToBitmap()
		bit_up_left = wx.StaticBitmap(self,0,img_up_left,pos=(0,0),size=(103,212))
		bit_up_rigth = wx.StaticBitmap(self,1,img_up_rigth,pos=(836,0),size=(113,211))
		bit_down_left = wx.StaticBitmap(self,2,img_down_left,pos=(0,550),size=(457,107))
		bit_down_rigth = wx.StaticBitmap(self,3,img_down_rigth,pos=(598,550),size=(362,135))
		self.button_capture = wx.Button(self,label="Capturar",pos=(33,265),size=(115,42))
		self.button_capture.Bind(wx.EVT_BUTTON, self.Capturar)
		self.button_clear = wx.Button(self,label="Limpiar",pos=(33,362),size=(115,42))
		self.button_clear.Bind(wx.EVT_BUTTON, self.Limpiar)
		self.cb = wx.ComboBox(self,value="0",pos=(33,462),size=(115,42),choices=self.cams,style=wx.CB_READONLY)
		self.cb.Bind(wx.EVT_COMBOBOX, self.ChangeCamera)
		self.camara = cv2.VideoCapture(0)
		ret, frame = self.camara.read()
		h, w = frame.shape[:2]
		frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
		self.bmp = wx.BitmapFromBuffer(w, h, frame)
		self.timer = wx.Timer(self)
		self.image = wx.Panel(self,pos=(160,80),size=(610,479))
		self.image.SetBackgroundColour(wx.BLUE)
		self.image.Bind(wx.EVT_PAINT, self.OnPaint)
		wx.StaticBitmap(self.image,5,self.bmp,pos=(0,0),size=(610,479))
		title_1 = wx.StaticText(self, label="IDENTIFICACIÓN AUTOMÁTICA DE LA CALIDAD DEL BANANO USANDO", pos=(80, 20),size=(640,18))
		title_2 = wx.StaticText(self, label="CLASIFICACIÓN POR REDES NEURONALES PROFUNDAS (DNN)", pos=(118, 50),size=(564,23))
		title_1.SetForegroundColour(wx.BLACK)
		title_2.SetForegroundColour(wx.BLACK)
		font = wx.Font(16, wx.DECORATIVE, wx.NORMAL, wx.BOLD)
		title_1.SetFont(font)
		title_2.SetFont(font)
		self.Show(True)

	def OnPaint(self, event):
		ret, frame = self.camara.read()
		h, w = frame.shape[:2]
		if ret:
			frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
			self.bmp.CopyFromBuffer(frame)
			wx.StaticBitmap(self.image,5,self.bmp,pos=(0,0),size=(610,479))
			self.image.Refresh()
	def Capturar(self,e):
		print('capturar foto')
	def Limpiar(self,e):
		print('limpiar foto')
	def ChangeCamera(self,e):
		i=int(e.GetString())
		self.camara.release()
		self.camara = cv2.VideoCapture(i)
		ret, frame = self.camara.read()
		h, w = frame.shape[:2]
		frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
		self.bmp = wx.BitmapFromBuffer(w, h, frame)
		print('Camara cambiada')
		

if __name__ == '__main__':
	devices = []
	for x in range(5):
		cam = cv2.VideoCapture(x)
		if cam.isOpened():
			devices.append(str(x))
			print("camara "+str(x))
		cam.release()
	app = wx.App()
	frame = MyFrame(None,-1,'Mi aplicacion', devices)
	app.MainLoop()
