#!/usr/bin/env python3

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import time
import os

import PySimpleGUI as sg
from datetime import date
import cv2

import numpy as np
from PIL import Image
from tflite_runtime.interpreter import Interpreter

#pip3 install pysimplegui

def load_labels(filename):
  with open(filename, 'r') as f:
    return [line.strip() for line in f.readlines()]

def evaluate(image_path):
    parser = argparse.ArgumentParser()
    parser.add_argument(
      #'-m',
      '--model_file',
      default='/home/pi/tflite1/model_p/mobile_best120.tflite',
      help='.tflite model to be executed')
    parser.add_argument(
      #'-l',
      '--label_file',
      default='/home/pi/tflite1/model_p/labelmap.txt',
      help='name of file containing labels')
    parser.add_argument(
      '--input_mean',
      default=255, type=float,
      help='input_mean')
    parser.add_argument(
      '--input_std',
      default=255, type=float,
      help='input standard deviation')
    parser.add_argument(
      '--num_threads', default=None, type=int, help='number of threads')
    args = parser.parse_args()

    interpreter = Interpreter(
      model_path=args.model_file)
    interpreter.allocate_tensors()

    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    # check the type of the input tensor
    floating_model = input_details[0]['dtype'] == np.float32

    # NxHxWxC, H:1, W:2
    height = input_details[0]['shape'][1]
    width = input_details[0]['shape'][2]
    imagenes = []
    image = cv2.imread(image_path)
    imagenes.append(image)
    img = Image.open(image_path).resize((width, height))
    # add N dim
    input_data = np.expand_dims(img, axis=0) 
    if floating_model:
    #input_data = (np.float32(input_data) - args.input_mean) / args.input_std
     input_data = np.float32(input_data)*1.0/255.0
    interpreter.set_tensor(input_details[0]['index'], input_data)

    start_time = time.time()
    interpreter.invoke()
    stop_time = time.time()
    output_data = interpreter.get_tensor(output_details[
      0]['index'])
    results = np.squeeze(output_data)

    top_k = results.argsort()[-5:][::-1]
    #top_k = results.argsort()[::-1][:1]
    labels = load_labels(args.label_file)
            
    for i in top_k:
        if floating_model:
          print('{:08.6f}: {}'.format(float(results[i]), labels[i]))

        else:
          print('{:08.6f}: {}'.format(float(results[i] / 255.0), labels[i]))

    print('time: {:.3f}ms'.format((stop_time - start_time) * 1000))

    #label = '%s: %d%%' % (labels[i], int(results[i]))
    #cv2.putText(image, label, (5, 25),           
    #cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    #


    label0 = '%s: %2.2f%%' % (labels[0], results[0]*100)
    label1 = '%s: %2.2f%%' % (labels[1], results[1]*100)
    label2 = '%s: %2.2f%%' % (labels[2], results[2]*100)

    #
    #label0 = '%s: %d%%' % format(labels[0], results[0])
    #label1 = '%s: %d%%' % format(labels[1], results[1])
    #label2 = '%s: %d%%' % format(labels[2], results[2])

    print(type(results[0]))
    print(top_k)
    print(label0)
    print(label1)
    print(label2)
    result = []
    result.append(label0)
    result.append(label1)
    result.append(label2)
    return result


def main():
    up_left     = 'up-left.png'
    up_rigth    = 'up-rigth.png'
    down_left   = 'down-left.png'
    down_rigth  = 'down-rigth.png'

    devices = []
    for x in range(5):
        cam = cv2.VideoCapture(x)
        if cam.isOpened():
            devices.append(str(x))
            print("camara "+str(x))
        cam.release()

    image_up_left = sg.Image(filename=up_left,
        size=(103, 212),)
    image_up_rigth = sg.Image(filename=up_rigth,
        size=(113, 211),)
    image_down_left = sg.Image(filename=down_left,
        size=(457, 107),)
    image_down_rigth = sg.Image(filename=down_rigth,
        size=(362, 134),)

    titulo = sg.Text(text="IDENTIFICACIÓN AUTOMÁTICA DE LA CALIDAD DEL BANANO USANDO\nCLASIFICACIÓN POR REDES NEURONALES PROFUNDAS (DNN)",
        auto_size_text=True,
        text_color='black',
        background_color='white',
        justification='center',
        font=('Roboto', 12),
        visible=True,)
    separator = sg.Text(text=" "*30,
        auto_size_text=True,
        text_color='black',
        background_color='white',
        justification='center',
        grab=None,
        tooltip=None,
        visible=True,)

    boton_capturar = sg.B('Capturar',
        button_color=('white', '#2A301E'),
        font=('Roboto', 14),
        button_type=7,
        size=(14,2),
        )
    boton_limpiar = sg.B('Limpiar',
        button_color=('white', '#2A301E'),
        font=('Roboto', 14),
        button_type=7,
        size=(14,2),
        )

    camaras = sg.Combo(devices,
        default_value=devices[0],
        font=('Roboto', 12),
        size=(14,50),
        background_color='#2A301E',
        text_color='white',
        readonly=True,
        enable_events=True,
        key='-camaras-'
        )

    video_camara = sg.Image(filename='',
        key='-image-',
        size=(500, 400),
        )

    espacio_image_iz = sg.Frame("",
        [[image_up_left,sg.Text(' '*12,background_color='white',)]],
        background_color="white",
        pad=((0, 10), (0, 10)),
        relief="groove",
        size=(200, 400),
        border_width=0,
        visible=True,
        element_justification="left",
        vertical_alignment="top",
        )

    botones = [
        [espacio_image_iz],
        [sg.Text('\n'*2,background_color='white',)],
        [boton_capturar],
        [sg.Text('\n'*2,background_color='white',)],
        [boton_limpiar],
        [sg.Text('\n',background_color='white',)],
        [camaras],
        [sg.Text('\n',background_color='white',)],
        ]

    espacio_botones = sg.Frame("",
        botones,
        title_color=None,
        background_color="white",
        title_location=None,
        relief="groove",
        size=(200, 200),
        font=None,
        pad=((0, 10), (0, 10)),
        border_width=0,
        key=None,
        k=None,
        tooltip=None,
        right_click_menu=None,
        visible=True,
        element_justification="center",
        vertical_alignment="center",
        metadata=None)

    centro = [
        [sg.Text('\n'*2,background_color='white',)],
        [titulo],
        [sg.Text('\n'*2,background_color='white',)],
        [video_camara],
        ]

    espacio_central = sg.Frame("",
        centro,
        title_color=None,
        background_color="white",
        title_location=None,
        relief="groove",
        font=None,
        pad=((0, 0), (0, 0)),
        border_width=0,
        key=None,
        k=None,
        tooltip=None,
        right_click_menu=None,
        visible=True,
        element_justification="center",
        vertical_alignment="center",
        metadata=None)
    Texto_1 = sg.Text("",
        text_color='black',
        background_color='white',
        key="-Texto_1-",
        auto_size_text=True,
        font=('Roboto', 12),
        size=(20,1)
        )
    Texto_2 = sg.Text("",
        text_color='black',
        background_color='white',
        key="-Texto_2-",
        auto_size_text=True,
        font=('Roboto', 12),
        size=(20,1)
        )
    Texto_3 = sg.Text("",
        text_color='black',
        background_color='white',
        key="-Texto_3-",
        auto_size_text=True,
        font=('Roboto', 12),
        size=(20,1)
        )
    showText = False
    Textos = [
        [Texto_1],
        [Texto_2],
        [Texto_3]
        ]

    DatosTextos = sg.Frame("Resultados",
        Textos,
        title_color="black",
        background_color="white",
        title_location=None,
        size=(210,210),
        relief="groove",
        font=None,
        border_width=1,
        key="-DatosTextos-",
        k=None,
        tooltip=None,
        right_click_menu=None,
        visible=showText,
        element_justification="center",
        vertical_alignment="center",
        metadata=None)

    derecha = [
        [sg.Text(' '*6,background_color='white',),image_up_rigth],
        [sg.Text('\n'*6,background_color='white',)],
        [DatosTextos]
        ]

    espacio_derecha = sg.Frame("",
        derecha,
        title_color=None,
        background_color="white",
        title_location=None,
        relief="groove",
        font=None,
        border_width=0,
        key=None,
        k=None,
        tooltip=None,
        right_click_menu=None,
        visible=True,
        element_justification="center",
        vertical_alignment="top",
        metadata=None)

    layout = [
        [espacio_botones, espacio_central, espacio_derecha],
        [image_down_left, separator, image_down_rigth],
        ]
    window = sg.Window('Banana Classification',
                       layout,
                       no_titlebar=False,
                       background_color='white',
                       size=(960,700))
    image_elem = window['-image-']
    text_frame_elem = window['-DatosTextos-']
    text_1_elem = window['-Texto_1-']
    text_2_elem = window['-Texto_2-']
    text_3_elem = window['-Texto_3-']
    camara = cv2.VideoCapture(int(devices[0]))

    evaluar = False
    cam = int(devices[0])

    while camara.isOpened():
        event, values = window.read(timeout=0)
        ret, frame = camara.read()

        if event in ('Exit', None):
            break
        elif event == 'Limpiar':
            showText = False
            text_frame_elem.update(visible=showText)
            evaluar = False
        elif event == 'Capturar':
            #ruta = sg.popup_get_folder(title='Guardar Fotografia', message="Carpeta destino")
            #cv2.imwrite(ruta + "/" + str(date.today()) + str(numero) + ".png", frame)
            print("Evaluar foto")
            evaluar = True
            dim = (500, 400)
            cv2.imwrite('image.png',frame)
            vals = evaluate('image.png')
            #vals = getText()
            frame = cv2.resize(frame, dim, interpolation =cv2.INTER_AREA)
            imgbytes = cv2.imencode('.png', frame)[1].tobytes()
            image_elem.update(data=imgbytes)
            showText = True
            text_1_elem.update(value=vals[0])
            text_2_elem.update(value=vals[1])
            text_3_elem.update(value=vals[2])
            text_frame_elem.update(visible=showText)
        new_cam = int(values['-camaras-'])
        if cam != new_cam:
            camara.release()
            camara = cv2.VideoCapture(new_cam)
            cam = new_cam
        
        if not evaluar:
            dim = (500, 400)
            frame = cv2.resize(frame, dim, interpolation =cv2.INTER_AREA)
            imgbytes = cv2.imencode('.png', frame)[1].tobytes()
            image_elem.update(data=imgbytes)

        if not ret:
            break


main()